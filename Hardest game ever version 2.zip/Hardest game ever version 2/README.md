# Hardest game ever version 2

A Pen created on CodePen.io. Original URL: [https://codepen.io/IDONTHAVEANAME_/pen/KKQjWWp](https://codepen.io/IDONTHAVEANAME_/pen/KKQjWWp).

Mario like simple javascript game