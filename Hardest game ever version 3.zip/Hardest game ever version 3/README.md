# Hardest game ever version 3

A Pen created on CodePen.io. Original URL: [https://codepen.io/IDONTHAVEANAME_/pen/abYBQNQ](https://codepen.io/IDONTHAVEANAME_/pen/abYBQNQ).

Mario like simple javascript game